# Pyarmor 8.5.0 (trial), 000000, 2025-02-23T13:20:00.415574
from .pyarmor_runtime import __pyarmor__
